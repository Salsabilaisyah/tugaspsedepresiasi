<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="style1.css">
<style>
a:link, a:visited {
  background-color: #f44336;
  color: white;
  padding: 14px 25px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
}

a:hover, a:active {
  background-color: red;
}
</style>
</head>
<body>
<div class="wrapper">
<center><p><b><font size="17">METODE DEPRESIASI</font></b></p></center></br></br></br>
            <center><a href="straight_line.php"><font size="5">Straight Line</font></a></br></br>
            <a href="reducing_balance.php"><font size="5">Reducing Balance</font></a></br></br>
            <a href="sum_of_the_year.php"><font size="5">Sum of The Year</font></a></br></br>
            <a href="unit_of_activity.php"><font size="5">Unit of Activity</font></a></br></br></center>
</div>
<div id="footer">
        <p><center> Copyright &copy; <?php echo date("Y")?> - L200190008 | L200190043</p></center>
    </div>
</body>
</html>
